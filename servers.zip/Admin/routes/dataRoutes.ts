import { Router } from "express";
import DataController from "../controller/DataController";
import authenticateToken from "../middleware";
const router = Router();

router.get("/summary/:payload",authenticateToken, DataController.getSummary);



router.get("/detail_summary/:payload",authenticateToken, DataController.detailSummary);
router.get("/active_calls/:payload",authenticateToken, DataController.activeCalls);

router.post("/settings",authenticateToken, DataController.settingPost);
router.get("/settings_data/:payload",authenticateToken, DataController.settingGet);

router.post('/update_timer',authenticateToken,DataController.updateTimer);
router.get ('/get_timers',authenticateToken,DataController.getTimer);

router.post('/delete_timer', authenticateToken, DataController.deleteTimer);

export default router
