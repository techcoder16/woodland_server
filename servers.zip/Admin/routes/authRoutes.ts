import { Router } from "express";
import AuthController from "../controller/AuthController";
import authenticateToken from "../middleware";
const router = Router();

router.get("/users/:payload",authenticateToken, AuthController.getUsers);
router.post("/getLogin", AuthController.getLogin);
router.delete("/deleteUser/:id",authenticateToken, AuthController.deleteUser);

router.put("/approveUser/:id",authenticateToken, AuthController.approveUser);

router.get('/test-token', authenticateToken, AuthController.testToken);

router.post('/create-user', authenticateToken, AuthController.createUser);

// router.post('/delete-user', authenticateToken, AuthController.deleteUser);

router.get('/get_team_members', authenticateToken, AuthController.teamMembers);

router.post('/update_team', authenticateToken, AuthController.update_team);


router.get('/getUsers/:payload',authenticateToken, AuthController.get_user);
    
export default router
