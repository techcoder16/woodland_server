import prisma from "../config/db.config";
import * as bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

import { Prisma,Role } from  "@prisma/client"
import { response } from "express";

require("dotenv").config();

class AuthController {
  static async teamMembers(req:any,res:any)
  {
  


    
    const user = await prisma.active_calls.findMany({
     
      select:{
          first_name:true,
          last_name:true,
          user:true,
      }
    });
    return res.status(200).send({
      message: "Get Team members!",
      data: user,
      deletion: false,  
    });





  }
  static async update_team(req:any,res:any)
  {
    const {user,email}:any = req.body;
    const User = email;
    const getTeamsofManager = await prisma.userTeam.findUnique({
      where:{
        User:User
      },
      select:{
        team:true,
      }
    });



  }
  static async get_user(req: any, res: any) {
    try {
      console.log("Fetching users",req.params.payload);
  
      // Parse page from query params or fallback to an empty object
      const page = JSON.parse(req.params.payload || '{}');
      const limit = parseInt(req.params.limit) || 100;
      const pageNumber = parseInt(page.page) || 1; // Ensure page is a number
      const skip = (pageNumber - 1) * limit;
      const searchQuery = page.searchQuery || '';
        console.log("fryrqbba:", page.searchQuery );

      console.log(`Page: ${pageNumber}, Skip: ${skip}, Search Query: ${searchQuery}`);
  
      // Define the query for filtering users
      const whereClause: {
        name?: {
          contains?: string;
        };
      } = searchQuery ? { name: { contains: searchQuery } } : {};

      // Fetch users and count documents
      const [users, userCount] = await Promise.all([
        prisma.user.findMany({
         
          select: {
            id: true,
            email: true,
            phoneNumber: true,
            name: true,
          },
          skip: skip,
          take: limit,
          where: { name: { contains: searchQuery } },

        }),
        prisma.user.count({
          where: whereClause,
        }),
      ]);
      console.log(searchQuery);
      console.log(users, userCount);
  
      if (users.length === 0) {
        return res.status(404).json({ message: "No User Found" });
      } else {
        return res.json({ message: "Successfully Retrieved Users", users, userCount });
      }
    } catch (err) {
      console.error('Error fetching users:', err);
      return res.status(500).json({ message: "Error Fetching Users" });
    }
  }
  
  static async getUser(req: any, res: any) {
    const { id } = req.params;
    const user = await prisma.user.findUnique({
      where: {
        id: id,
      },
      select: {
        id: true,
        name: true,
        email: true,
      },
    });
    return res.json({ user: user });
  }


  // static async logout(req: any, res: any) {
    
  //   const { email, password } = req.body;
  //   try {
  //     let getEmail = null;
  //     let isMatch = false;

  //     if (email && password) {
  //       getEmail = await prisma.user.findFirst({
  //         where: {
  //           email: email,
  //         },
  //       });
  //       if (getEmail && getEmail.password) {
  //         isMatch = bcrypt.compareSync(password, getEmail.password);
  //       }

  //     }

  //     if (isMatch && getEmail) {
  //       const user = {
  //         name: getEmail.name,
  //         email: getEmail.email,
  //       };
  //       const accessToken = jwt.sign(user, process.env.ACCESS_TOKEN_CODE);

  //       return res.status(200).send({
  //         message: "Login Successfull!",
  //         data: { success: true },
  //         accessToken: accessToken,
  //         user:user
  //       });
  //     } else {
  //       return res.status(401).send({ message: "Login Failed!", error: "" });
  //     }
  //   } catch (err) {
  //     console.log(err);
  //     return res.status(401).send({ message: err.message, error: err });
  //   }
  // }

  static async approveUser (req: any, res: any){
    const {id} = req.params;

    try {
      if (id)
        {

            const user = await prisma.user.findFirst({
              where: {AND: [{ id: id}, {approved: true}]
            }
            });

              if (user)
                {
                  
        
        return res.status(200).send({
          message: "User Already Approved!",
          data: { success: true },
          deletion: true
        });

                }

         const result =  await prisma.user.update({  
            where: { id: id }, 
            data: {
                approved: true 
            }
        });


        const userData =  await prisma.user.findFirst({  
          where: { id: id }, 
      
      });
      const accessToken = jwt.sign(userData, process.env.ACCESS_TOKEN_CODE);
        const resultObject = {name : userData.name,email: userData.email,activationToken: accessToken}
 
          return res.status(200).send({
            message: "User Approved!",
            data: { success: true },
            deletion: true
          });

        }
        else
        {
          throw("User not Approved");

        }
      }
        catch (err) {
         
            return res.status(401).send({ message: err.message, error: err });
          }




  };

  

static async deleteUser(req:any,res:any){
    
          try { 
          if (req.params.id){
              await prisma.user.delete({
                where :{
                id:req.params.id
              }
            });

            return res.status(200).send({
              message: "Deletion of User Successfull!",
              data: { success: true },
              deletion: true
            });

            }
            else
            {

              throw("User not Deleted");
            }
          }
          catch (err) {
            
              return res.status(401).send({ message: err.message, error: err });
            }

}

  static async getLogin(req: any, res: any) {
   
    const { email, password } = req.body;
    try {
      let getEmail = null;
      let isMatch = false;

      if (email && password) {
        getEmail = await prisma.user.findFirst({
          where: {
            email: email,
          },
        });
        if (getEmail && getEmail.password) {
          isMatch = bcrypt.compareSync(password, getEmail.password);
        }

      }

      if (isMatch && getEmail) {
        const user = {
          name: getEmail.name,
          email: getEmail.email,
        };

        
        const accessToken = jwt.sign(user, process.env.ACCESS_TOKEN_CODE);

        return res.status(200).send({
          message: "Login Successfull!",
          data: { success: true },
          accessToken: accessToken,
          user:user
        });
      } else {
        return res.status(401).send({ message: "Login Failed!", error: "" });
      }
    } catch (err) {
      console.log(err);
      return res.status(401).send({ message: err.message, error: err });
    }
  }

  static async getUsers(req: any, res: any) {

 const payload = JSON.parse(req.params.payload);
    // const { searchQuery } = req.query;

  
  
let whereClause: Prisma.UserWhereInput = {
  role: {
    not: Role.Admin
  }
};

if (payload && payload.searchQuery) {
  whereClause = {
    ...whereClause,
    OR: [
      { name: { contains: payload.searchQuery } },
      { email: { contains: payload.searchQuery } }
    ]
  };
}

    const users = await prisma.user.findMany({
      where: whereClause,
      select: {
        id: true,
        name: true,
        email: true,
        phoneNumber: true,
        website: true,
        company: true,
        country: true,
        no_of_employees: true,
        approved:true,

      },
    });

    return res.json({ users: users });
  }

  static async testToken(req: any, res:any) {
    return res.status(200).json({ message: 'Token is valid'} );
  }

  static async createUser(req: any, res: any) {
    try {
      // Extract payload from request body
      // console.log("asdjasdkljaskdljakdsjkalsd");

      const { email, name, password } = req.body;
  
      // Ensure payload contains the required fields
      if (!email || !name || !password) {
        return res.status(400).json({ error: 'Email, name, and password are required' });
      }
  
      // Check if the email already exists
      const existingUser = await prisma.user.findUnique({
        where: { email },
      });
  

      if (existingUser) {
  
        return res.status(401).send({ message: "Email Already in use", error: {response:{data:{message:"Email Already exists"}}} });
      }
  
      // Hash the password
      const hashedPassword = await bcrypt.hash(password, 10);
  
      // Create a new user in the database
      const newUser = await prisma.user.create({
        data: {
          email,
          name,
          password: hashedPassword, // Store hashed password
          role: 'User',
        },
      });
      
      // Respond with the created user
      return res.status(201).json({ user: newUser });
  
    } catch (err) {
      console.error('Error creating user:', err);
  
      // Handle specific errors (e.g., unique constraint violations)
      return res.status(401).send({ message: err.message, error: err });
    }
  }
  

}

export default AuthController;
