import prisma from "../config/db.config";
import * as bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

import { Prisma, Role } from "@prisma/client";

import { readFile, writeFile } from '../utils/fileHelper';
import fs from "fs";
import path from "path";
require("dotenv").config();


export const timersFilePath = path.join(__dirname, "timers.json");


const loadTimers = () => {
  try {
    if (fs.existsSync(timersFilePath)) {
      const data = fs.readFileSync(timersFilePath, 'utf-8');
      if (data.trim() === '') {
        // Initialize with default empty object if file is empty
        saveTimers({});
        return {};
      }
      return JSON.parse(data);
    } else {
      // If file doesn't exist, create it with empty object
      saveTimers({});
      return {};
    }
  } catch (error) {
    console.error('Error loading timers:', error);
    return {};
  }
};

const saveTimers = (timers) => {
  try {
    fs.writeFileSync(timersFilePath, JSON.stringify(timers, null, 2), 'utf-8');
  } catch (error) {
    console.error('Error saving timers:', error);
  }
};

class DataController {
  static async getSummary(req: any, res: any) {
    const payload = JSON.parse(req.params.payload);

    const searchCondition =
      payload && payload.searchQuery
        ? { agentName: { contains: payload.searchQuery } }
        : {};

    const sortCondition = payload.sortColumn
      ? { [payload.sortColumn]: payload.sortDirection }
      : {};

    try {
      //@ts-ignore
      const data = await prisma.summary.findMany({
        where: searchCondition,
        orderBy: sortCondition,
        select: {
          user_id: true,
          agentName: true,
          totalCalls: true,
          totalTalkTime: true,
          incomingTotal: true,
          incomingMissed: true,
          incomingAvgPerHour: true,
          incomingTalkTime: true,
          incomingAverageTalkTime: true,
          incomingMaxTalkTime: true,
          incomingAverageRingTime: true,
          outgoingTotal: true,
          outgoingAvgPerHour: true,
          outgoingUnanswered: true,
          outgoingAnswered: true,
          outgoingTotalTalkTime: true,
          outgoingAvgTalkTime: true,
          outgoingMaxTalkTime: true,
          active_calls: {
            select: {
              presence: true,
            },
          },
        },
      });

      return res.status(200).send({ summary: data });
    } catch (error) {
      return res.status(500).json({ error: "Internal Server Error" });
    }
  }


  static async activeCalls(req: any, res: any) {
    try {
      const data = await prisma.active_calls.findMany({
        select: {
          first_name: true,
          last_name: true,
          domain: true,
          group: true,
          site: true,
          user: true,
          uid: true,
          email: true,
          presence: true,
          message: true,
        },
      });

      return res.status(200).send({ calls: data });
    } catch (error) {
      console.error("Error fetching Details:", error);
      return res.status(500).json({ error: "Internal Server Error" });
    }
  }

  static async detailSummary(req: any, res: any) {
    const payload = JSON.parse(req.params.payload);

    const searchCondition =
      payload && payload.searchQuery
        ? { user: { contains: payload.searchQuery } }
        : {};

    try {
      const data = await prisma.detailed_calls.findMany({
        where: searchCondition,
        select: {
          user: true,
          dateAndTime: true,
          source: true,
          destination: true,
          duration: true,
          direction: true,
        },
      });

      return res.status(200).send({ details: data });
    } catch (error) {
      console.error("Error fetching Details:", error);
      return res.status(500).json({ error: "Internal Server Error" });
    }
  }

  static async settingPost(req: any, res: any) {
    const { id, email, time } = req.body;

    try {
      
      const result = await prisma.settings.updateMany({
        data: {
          email: email,
          time: parseFloat(time),
        },
      });

      console.log("Success: Settings Updated");
      return res.status(200).send({
        message: "Settings Updated!",
        data: { success: true },
        deletion: false,
      });
    } catch (err) {
      
      return res.status(401).send({ message: err.message, error: err });
    }
  }

  static async settingGet(req: any, res: any) {
    
    try {
      const data = await prisma.settings.findFirst({
        select: {
          time: true,
          email: true,
        },
      });
        
      return res.status(200).send({ data: data });
    } catch (error) {
      console.error("Error fetching Details:", error);
      return res.status(202).json({ error: "Internal Server Error" });
    }
  }
  static async updateTimer(req, res) {
    const { userId, elapsedTime } = req.body;

    try {
      const timers = loadTimers();
      timers[userId] = elapsedTime;
      console.log(elapsedTime,timers);
      saveTimers(timers);

      res.status(200).json({ timer: timers[userId] });
    } catch (error) {
      console.error("Error updating timer:", error);
      res.status(202).json({ error: 'An error occurred while updating the timer' });
    }
  }

  static async getTimer(req, res) {
    try {
      const timers = loadTimers();
      res.status(200).json(timers);
    } catch (error) {
      console.error("Error fetching timers:", error);
      res.status(202).json({ error: 'An error occurred while fetching the timers' });
    }
  }

  static async deleteTimer(req, res) {
    const { userId } = req.body;

    try {
      const timers = loadTimers();

      if (!timers[userId]) {
        return res.status(200).json({ error: 'Timer not found' });
      }

      delete timers[userId];
      saveTimers(timers);

      res.status(200).json({ message: 'Timer deleted successfully' });
    } catch (error) {
      
      res.status(202).json({ error: 'An error occurred while deleting the timer' });
    }
  }

  
  
}

export default DataController;
