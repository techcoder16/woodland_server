import express from 'express';
import cors = require('cors');
const app = express();

