  import { PrismaClient } from "@prisma/client";

  import { Role } from "@prisma/client";
  import bcrypt from 'bcrypt';

  const salt = bcrypt.genSaltSync(10);
  const hash = bcrypt.hashSync("12345", salt);


  const prisma = new PrismaClient();

  async function main() {
    await prisma.user.upsert({
      where: { email: " " },
      update: {},
      create: {
        email: "admin@hunter.com",
        name: "Admin User",
        role: Role.Admin,
        password: hash,
        phoneNumber: parseFloat("03211045386")
      },
    });



    await prisma.settings.upsert({
      where: { email: " " },
      update: {},
      create: {
        email: "abbasi.work22@gmail.com",

        time: 10
      },
    });
    
    
    
    
  }
  main()
    .then(async () => {
      await prisma.$disconnect();
    })
    .catch(async (e) => {
      console.error(e);
      await prisma.$disconnect();
      process.exit(1);
    });